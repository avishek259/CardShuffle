'use strict';

/**
 * @ngdoc function
 * @name shippingFormApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the shippingFormApp
 */
angular.module('shippingFormApp')
  .controller('MainCtrl', function () {
    //TODO
  });
